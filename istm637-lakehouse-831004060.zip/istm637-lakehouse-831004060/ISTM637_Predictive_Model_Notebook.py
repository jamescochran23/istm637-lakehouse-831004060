# Databricks notebook source
# MAGIC %md
# MAGIC <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARwAAABtCAYAAABz/d4wAAAAAXNSR0IArs4c6QAAAIRlWElmTU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAABIAAAAAQAAAEgAAAABAAOgAQADAAAAAQABAACgAgAEAAAAAQAAARygAwAEAAAAAQAAAG0AAAAAvGfmPwAAAAlwSFlzAAALEwAACxMBAJqcGAAAJzNJREFUeAHtnQeYnlWZv89kWnpvpJBJpyW0QAATOoIFRRaVVRC7rnupu66uuqv+lRXXxcuuuLouugqiiIAUAekgAQKBUEJCepn0NumTZMr/vt/5TvLly2RmIpOZIZ4n1523nfeU33ue5z1v+yaEZEmBpEBSICmQFEgKJAWSAkmBpEBSICmQFEgKJAWSAkmBpEBSICmQFEgKJAWSAkmBpEBSICmQFEgKJAWSAkmBpEBSICmQFEgKJAWSAkmBpEBSICmQFEgKJAWSAkmBpEBSICmQFEgKJAWSAkmBpEBSICmQFEgKJAWSAkmBpEBSICmQFEgKJAWSAkmBpEBSICmQFEgKJAWSAkmBpEBSICmQFEgKJAWSAkmBpEBSICmQFEgKJAWSAkmBpEBSICmQFEgKJAWSAkmBpEBSICmQFEgKJAWSAkmBjqhAUVtU6oow5qQQikbWhVBfFOo7hdCpNoS64taeFoVONfWhrqSpaSe21+XSFYfi3bWhtrSxaUt1obzi2lA0s3vosexnYcbulu6X0iUF/hYVKGmLRheFojfXh/BWIkxRfSiqM+g0NSUumZSgFA56SlnZfgeYEmyKasiXoFRUUxfqDzg9CF06dwr13yD9KkgB5yCES0n/9hRok4BDsBmGtCcydURV39yUNFm6bEDEf+00bVFvIHCVErj6bwub2kTLFlUqJUoKdFAF2sRJiBjlRJCyDqrBa6oW14eBgFNcHoppZrKkQFKgKQX0l0NuucubQ15OexVA++p3hto2uR/WXm1M5SYFWkOBNgk49dk9mdaobsfMg3tSRWmE0zGPTapVx1KgTQLO4T7C4QZ4/Zawu0207FjdJ9UmKXBwCrSJkzAC4GnT4WuOcHoE7h0nSwokBZpUoE0CDiMAH1UftpZGOO1+aH340ReOh9J2r02qwAEVaJOnVDzWbqNyDtjOQ7qhFUY4PalgLxgAngSWwlpo6smXN6l98jcOdLJ1sAIM7nE/R5b9oTt0hnLQdsKsbO7w+M/2G2wugf8HVdDaZhldYTisho3gO13JDkKBNhnh8FrNYX1gWmGEM4lj9jWYAc/A26G5M7UBZyA8AO73LegB+U/LPL5vhK/Dn8B0ci88BP8Co+Fg7WPsYFB79mB3PETpDaSj4HIwKBwKcwR1BtwH7wK1TnaQCrTRyKNlI5xOxZ1Cl55dQ79hg0OP/n1CXW1t6FRcHOpqmJbsndayXMzy3mkNyyUs56a7mZay3MJpza7doaSsNMTpynlLwuY1G7PllujZCiMc7//k3wOqYHkkvAoHMkc27wBHMTp//v4shuPgnWDw8g3ouTANNJ3HQHQOLIQFcDD2+VziCqZDYEVuub0mtr0bdIH8gHuw9Sljh5PBt8YdYW6FaGqs1o4gX0sZMb+/yWkbBZwiOrzHq2kzSPTo1zNMfNOZYfBRo8JuAs6eIBKDCdOS0r3BIQaJON1N8CgleDQ1LSsvC7t37gqlTHcxddn9O3ftEkrJe/rN94TZjz7T4oDTCiMcRzNxFGgnPxamQlMBp4LtF8BjwLdqoRryHaGC5cvAY/womE5H0gbBN8HtT8PB2MUkHgkPwblgHf4P2tM6UbiXiQaD5jta4zU1D0ctV8Ej8DjkB5wdLHs8fgLTQb2THaQCbRJwGAGUtKQXOMLp0bdXOPrs08LIKSeHDRurQl1dHdSHTp2K8qZ8ftmJzzDZ1hrTej62KCsrC+Xl5aF//35h2Ytzw/ynXmixlK0wwnEEYtBxamceC5PgelC6Qvm8hPByajx8GnQUz/D56VxXAbfAb6CxwPIw6w/WvAzT+d4HC+FL8NcEnGHsZ5DwXsiBAoVBwPtPtk19bN9m2A5qFa2OGTVxBFKUW2n7+4D5W98Y0JndY6YfnFsy/6HwFtgGy8G8rMM6cN0y+BV4j8g888105tELHCnFepjW4BTr63rb46WfbbPtbjO4WYbLh621ScBpeEqV7wuN68n7OqGIQFJPIAlFRWHbtu2hqqoq1DLSKWLZwNCyKT2P4NXS/Uq4HOvVq2fo0qVL2LJtW6iu3smlnP2nZdaKIxw73Q/hYzAA7JCuKxRPxxgOHr9p8NbcfOzkLGb77GLq9ta6iTqIvBxNOVLyxulP4ZMwGRoLaLbhcrgX5oEB4BLoAgYIHfh2KGwfqzIzkIwGg69lG6AehxchOjCzWVBwWwxcOvwxcC5472opGHjyzQOs018G6mZ9RoEBYyIUw1qwbrfBErA9XsbeD7Og0MzvLDgSDD5bwPouBOtrOeZnkFNH62idK+F5mAkxDbOHn7VJwEHjFpXDG8lZsPHSqkvnzuHI4cPCEYPpZxyClgeb+rB27bqwc9euMKB/f0YupaHYIJYLVnVMOxUxOqpndJSbFncqDlu3bg2VlcvD8BHDG0ZNtfb1llkrjnAMEC+DZ9QR8Ca4A3ZAvp3HwhkwH+zUdlKdOL/SOpSd/j1gh38VXqudQwaOHH4Mjhh+Dgacr8MFUGgVrPgBfAF0rG9BNANQNfwjfBseAkcuWmc4Gz4NBimDgEHE9r0bngUDidpors8f4ajjSPgAjAMD41OQb6YfBpfDUlgJ9lO1tCy1M40BwvWuGwKmXwz5AWcCyxfCpaA+7mc+2+Bi+AZMgwFgew2g5mWe5m26TaAmamWgOyzNxraB+ZTK49a0xRGO920cdXTv/tdVbyOXYru5YezlVu9evRjteLJq2nZUVzOyqc4CU403m1uwT8yxlUY4ngF1nK2gAxhw7MAPgmdvt0U7mhk76x9BJ7XD2kiDTLTFzNwLU+FK0HFnwyKoBgPGwdq/5nb4bm66kOlKOAE4M2SjHiZ7LB70z7KmP1j2n8H26JSj4Ey4DFx3P2g6q6MF67wY1oBB13UGNttkUI4Bx3a7fy3EMnVg6zYZYjpm95gOfzocCY/CEzAQ3g46/mOwFKxLJdgZ1Xw4GBA1y+0LbwFPDu5vMLRc6+IxMQB5jAyao+FCMKAYgNZDzMN8zN/lw9b+Oo8+aDlaOMJh9OHllE+cCm3XjuqwfeOmsH7ZqixNHSMQL3uc9hjQJ3Tn3k+PAf2y3Tpx+bWT4LG5ajPuuz3s3Loj7Ni0dZ8nWV16dg99hw8O5d27ZoHJe0SOguq5X1TCT3J5OdZSa8URjp3bDufQ2uG2DtEbaEjYBW5zJOOZUge8Fayojij5QWk2y9eBHfkkGAE6w+OwDGbAwdi5JD4Rfg9rcjsaHO+Ej8IkuBsKzQBgsPkJfCJv42Dm3wDHwVRYDDHg2NZX4X/BOhvY1ECn1UnfDQaMaLbbIKCDq6Hm/r+DL4N66fiOBqMZaAwuBoPp8AgYyHfDcrDcBRBNHe2YHoPYQR0FTQCDoHX7FdwBBizzMWBaT/PrBqPAfO6CG2E+aCNhOJheTQ9bi8Id4ga2cIRDoPAejiOcQqtasTLMuPWecMtX/5sYUkWvws355/Sk888M53zk3eGUd701281g4QhlGyOdGbffF579w4Ohct78Pen1gAlT3hAu/dqnwujJx4fybl2yG9LEmyz41PA7gO00wrFqduJHwI5pwPGsuSGHwcYzpJ1zNeiImk4TnSFbwX9VYHB5L3wYLofP5HiR6fXwY9hfbFY2Yp/KrftZwbbvsWzAuRoaCzgGAOv6Bcg31z0GOt1YqIBotczMgjmgJhEDxvfhKOgEBpFtuflqpu5nWm0VPARfAe/JGIDVQ3Pf0fBmsA6bwHV14P4GC4NXvrldrUwTNfN4XAIGVPO5GmI+zGaB2dGMeQ6DnaAe4ny0xcwsAdfbhsPW2ijg1OFEatm0OcLwyVNjI5wi7rP4To6Pssu2xxFtQ36m972caAYLg04pwaukvDR7TF6ajeBjCnoFoyPzi9XypvHIkSN4LF7CY/LSth7heEY30ESRNjOvc9lRdfQfwhNgB78K3DYN7Pxa1xxx2XXuq2NshBvgfvBsexacCgaKf4ZjQadtynSok2ENPFWQUEf+E+i8BsgnodBWssKAkG+xfgZG653vgKZTC/vnCDAgefZ3XXlueQHT2H/d305hJ4gaWp6B+jk4HpbA46D1hp5gmT+Hl8E8DBbu77EodHy3W55p3K45fzR4XDwmmumi2UbR1sEMmAnnw4m55eeZSiUc9hYP2CFuaCccKuredFE13OzdWLkyrJm/iNFOMZc4PKEiMKxbtDRs37Qlu+wpzKGEIJQ/KoojnLrdu7OX/3xpsNBMX7Wccnp3C1169eC9nJ1ZOVs3bw3VlENBhbsccLkV7uGUkblnVQu1w9vZdVI76FS4E6aDTnIS3Aj5jt3YCIckWX463iLQ4XTWW+EMMI8K+BJ8EZqyyWz0DK1Fx2pY2vf/T7GYX6+41QBqUC00g6HtdpsaRDuGGQOhU526K1h39XHqsu2KAcLpDlC3eOB0fHW5Hd4DYyDaJGbGwnp4Ljf1ksd93L+5EY7bNes8FPKDjOsbM4ObQccAdxZUwHFwApwO1uMlWAymPSytjQJOHQdGP2raDALbqraGBdNfCNurGoJLw2PwOtZvDstemtPoy3g1vLyXPypyhFPDCKeMUYwvCfpGcqFtWrU2zP3Ls9wTWrFntOObzeazduHSsHO7/bdl5j2cAaHL/oW0bHdTRYdTpOgwC5i/C86DQTASxoGXEYvgBYims+iETXV8t8VGTWP+cnC08lloLuB8njQtsTNJ1Bc2FCRu6uDbXvthDEg68flwEQwAg+5CqALb4Ghicm7qvhLX549wWJ219x6mb4ZB4GhEXXXwCfAKGPRqwDwMXOIIpvB4ut16WobbNdOY3iDYXJBwf9vgaHA2WBcD3xvgQvBE8iDcAGugsHxWvf5NAdvAWjbCqdlVE9YuXh3u+On19CL70V5zuZy+Vl7kyHlfa2yEU+Jl1e5doYZRjpdbvD5Ir9q1J9dlC+aHZT+ZTw+KfWdvnjWc4ArLLyFlcdbf9qaLc45w1oYd+w+jYoLmpzqZDmejo3MuZd6z81fB0cWlYAe1I3oJlN/BXbZ8O39L7elcwub6wHjSTYVVcERun8YmOq9O5Bn7ocYSNLKuH+tsrw6vBpplXAC2z6C4ENTFttlGA+7p4D7uK27bAWqT33F08krYBI4mPgbfys3b7rvBcjTzcF/38VgUHk+3W6ZlxBEOs9mTLI+PQaeltpiES8BgaDlX5vgC0ydhKzQ1kmTz69Oa62yt1Kr6/b26kZy99CnvWhou+adPhHFnnJxd4tQz6vCSqmr5qrDgqRnh8V/fFXZus2/ttWyEw0gm2t4RDiEiN8IZfdJxYer73hbKujU8ldrNy32rFywJD//81rBjC8eXrhZfKjz//ZeHo6Z6wrEvN9j8p18ID/3s93Fxn+khGuFYhg6wAKaAx8pOfT049M43Rziis2jxuBY6YMPWBucalVvQGZuy/8ht/EpTidh2DdwAn4SHoCVm/ayzBy+OcBx5OErSIVeAB0EdxPb/PZhmDsT15uEIT+fde9AatrMqGym6/jQYDeZj/n8Ag7VmXcR0Q6A35JtlqKtlxM7mJZttfQ9UwAiwzvkBicX9LNbbspw3yIyHU6EC5kEKOIjwV1oRB0BdmzYfTZd2Lg1Djx4dJlw4dZ/Eq+ct5LH4eraX7xdwshEOI5lo3sMpHOH0PmJAlmcXbg77oeZO3mJet2RFeP7OR7OPRA1iZV07h4oTjgonvOXscMy59M28KvO0nIBzM0XYR/a1QzTCsZBquAMuhlNgGdwLKyHfCkc4Xdh4FFwAS8H0njWt/FMwGa4D7YcNk0b/1+k8EHb++xtNsXfljcz+DC6BMTAfmrMqEjhy8ODFEY7rNsNIuBJmg8HIuoyDy8ARhfc8bI+Yh85vwMg7aiw1mGnHgjpeBOWwEPJ1dF/1tizPNmvBdaa1DpZRA66Lnc3pw+AJwbp9Bp4AR4Om6wHdwfJtVwUcCZbhZWdnME/3rQCPY7zEY/bws3gmPMQta9k9HN+B8bLKJ1WOWgwk0XzfZtuGTdlN4LguThsd4XDfpoyRURzh+HHmrh07Q7+K3lnQ6tavL/l3DkefdUp48f5pWRDrzDs5Z7znraHi5ONCt759YvbB+z1bKftAdghHODrR78AAYcfU8eeCnTXf8kc4OpzOMRE+CUuhEmyA65+EaDrct+JCI9OjWDcYpsFiaM6uJcFX4XPwMWjM+Vm9jzlyKAWdUJsFBoM3wWfhGfCypxdYF53cfRzRmL/EZfuzAajQlrBCDUx3IRhM5kG+ma9B4WWYAG+DoWCe/w2mdz5/hOM+L8Fj8PYcXrqtAbdZnvU2AHn8xoMBc2tu2XbZjgHQD6bDq2DAPSzNDtgG5j2c5s2PNHdt380TqqXZOzT5e2xcsSYsnjkne+kvf73zjY5wuDxzpBPv4axdtCw8ddMfg5dS0Xzpb8pVbwtHjKvI3r8pKSsLx5x3Rug1qH9Mkk1n3vlgeO62+5hvrC/b41vlHk45BXhGzD8mdtrFoIN45psJBh07b77pCDqt+1pJz5QLwDPzcLgUPgBXgfYwfAkqoKnO/QO2a9c2TJr9/4Zcincy1dGieZY/kHVjg04X09jO38ODcAS8B6z7VFiSm5/B1LNRbK9TMY8iKDT1Wg5PggHhaXgU8s0060Bd3DYGPgxXgBrGMjxGBh3NYLcDvgP/BtbLy6LL4UpQhxgQTbcCrLdB54PwD+AxGQEPwGegEjzuh6WVtE2rWjbC4b0/nhgVhb7DBoWuvXvuUzWDwMCRw8Orf9Hn9jWDSHHhPRyeeJURdLIRDi/y+ZRr+asL99mxlO+1KiadEAaNrQhb1m0Mx547OXTna3Ev2/LN38dZPnvfffO3t8II5xny83LpR7ASaiHfvs3CL8AzsGfHQvs6K3QCg4dnVTv5C/BPoDPbyd3u+kegpebISnO/ltgCEuU7vA6ooza1/+fYbnBaD9Gsuzr8Agyk5lkNjtLWgI5pni7bXoPwzaCOa6ExM6BYF/VbAo0dUB3dNlwDPwF1cz9HHZb1LFwApsk36+JI58vgsbLO0azPCvAkYJovQj+wLh4Ty7RtppMWnZxJ97q0Ngk4HA1jSbNW1qVzGDXpmNB/xFDus5Rlny2snb849Bw8IPtsYfxZk8OTv7s3e4ztJVbztrdUg5KP2r1cy4z3bIqye0adw9jTTwhd+eEv7xuVdSnPPm+oq2v4MS/T7uDdnO1wCM1AIgeyuQfakFs/u2C7DuBIQV6Lmc9rtebymNVIAc3V/eWCfWpZrsxRsGnPok4+DpaCAcDL1UKzrgZtacys17RGNtipmquzu23I4fzfpBllO4x5D2XSO94YBow8kns1u8PWdevD7IeeyO6h+AuAIydNDP0rhvAkq8vB19mQtzf+ZE+mNixdnt0TGn3qxHDqO98URvAky9FN1YpVoYqXD/cY+/oEK9nrUgEP3Cg4EUbAY7AckrWDAh0q4BTxcxETLjwz9Bk6KGxZuyHMuu+R8Mxt9/A0qTL7xsp7NeMYjfQY2KcZqWJw2Pfkmh80DDYv3PXnLLANGjeKYDOBnzftkZUzb9r0MOfR/BPZvvk0U3ja3LEU8OB5L+Ud4Cjkp1A4ImRVsrZQoE0uqVrSkD5DeGx9/mmhax9+ToLvmfzy+9iLzglHnjQx9BnmvUNuRvCF91kfvCysnLskrF20PLv0aUnejaWpWrUuvHT/0+H4iy/kJvGA7MZz9m7O3Plh5ZyFoXu/5oJaY7mmdR1EAYfAb4V/Ae+RDAMvZ34J3hj2EixZOyjQYUY4fYYMDBMumsolTdme0UzPgf3D0OPG77mBXMLlzpBjxvFUaWTo1rvXa5Jr57bqsH7pyjDv8WfC5rUN9yt9F+fJ394dVr66iJFP6pOvSeD23dlRjXhT1uHudLgJfgveK0tDVkRoD+sQIxxv1A4aMyKM5e3iMp4crVuyPGzgd2928Zs2Db97U5z93s0Qfli9jPs3wyeOD4NGD+PdmKbuszYnZ3328t/0W+4NvYcOzoLaRt5mfu7OR0L3Xl352YoTmssgbe+4CvikxydCPmnyKdN8WACrIVk7KtDOAaeesW0tf6lhIG8Xjwr9Rjjy5VXYm+4M9//w12HliiXZsqejE88+O7z/x18OA0ZX8FTp+FD58pww55kZvIlVlqVp7j9/2Mu/1BDNQLZ1/aYw7fZ7wtHnnhH68WNci5+dyahnVeg0YuA+7/v452ZqanfzHLOd5YqVT9PmFPCpkY+yJVkHUqBdPag7b/Oe89HLwrgpk8KwY8ftkaXixKPDmNMmhg23NrxS0bVXtzD0mFE8vRrBezVl/FLf0HDeJ64MY6dMDjd/8VqeWvmGeNM2fuqp4fJrPxd8EqaNn3pK+Mgv/yv8/KP/HpbOnBV279geZj8yPZR3Kwlnfejd4bS/v3hPhhd/8ePcyB4cbr/6x3vWpZmkQFLg4BVo14DjU6ehx44No06ZGLxfE61bn55c4vSIi7yTUxLKu/M3o3hPR/MDzIGjR4TOPFUy7f5/YWH/S3TzHz7hqD159hjQl8fsE7JgNX/6i2EpfxpmQ+Uq7h/xnvmo4fvUZxBlDT16DPuab3wCtierNJMUSAq0UIF2DTi+a+MnB0tnzuapVN/s8wJfzFs5dxE3cn2o0GD+ns0mniote3FO9qFl/C3jreureClv296X+eIOjUy3rNuQ/Z5OHTeD41/x3LJ+Y/Z91YZlq7O/7lnE7+d07l4W1vB7OCtmz8/WxaysZ7KkQFLgtSnQrgGneuu28PwfHwgLpj2Xfamd/coeL9j5oeTaxSv2tGzX9p1hwZMvhNu/+r2GAUb2a3z8UPr26uDj7UEjh+5J2zBTMAohfSXB6ravfDf3Ah8jFcrxSZUBy4Dmh6P8qT1uVNeGp2+6K8x7bPo+vy64jqCURjcFMh/cok9EW/J6+MHlmlK/rhRo14Djl+Er5y4NaxatzEYdmdPzuYFfdvsFeDT/bMv65WvC1o2bs0fm3gDu3rdn6MULgIMqjsh9e7X3Eizu528W9xrYLwweMzx7W9mvvqtWbwjV2e/pFGVvGddU86Nc/vYE5rSWOlW+siisWlC5z8PT/BvOMf9WnF5GXt406gufBKOtAvSGL8Mx4Hc8/wG+V2KFB8Hp4HdF34W7wG3aF6AbfBO2wRB4I/huyofAa8s3w4VgdHb49ie4HgrtbFY8XLDyv1i+GuLnATOZfx4+ANGs08fBs4HD1UnwQTga/NbIJ0d/hlvAG3i2ZRRcA9Yp1tX2+8RpKwyAn8J14L6+G+GTqOFQDOqibuqkXuPhH6EC1MYy/x2sz8ngR5ZOy2EhPAq/gy0QzbqcC+o1FXbCK3A33AHasXAeqLF1Upd7wbp6DD8Mlvkj0LqD+V0Kn4I14LrRYNox4PGzHk/BH8AyrYvtPBPeBNa9DNbCE3A7LAU1OBs+Bt+GVyG/TSy2j5W0T7ENpRo4tm/RH/Y3/xpDNAPBLkYz+T/76X2Vsz787uyxef8jh2Q3lGP6GCl8hD5q8smh79Ch2ceZfkt17/d+mX1T5d8e1/LLcdmnV9v9Qa5GDk9hWtPnbG9l45qDmx5Bcp3OTmfntcPaCe1Mdi6ddBN0gmgjmbkMDFInwGLQ6TVFNb/3g53+HDgV5oEfCp4FlmMg0ZHtB04LrQsranMrr2W6BCbC58E6Xg1aTY5sIfffDKaWZRvM36BwAfwGFL8KbKP566QjwHaa1nYOBB3KoPV9MD8Dg+24BTQDl8vLwbY7Nb9KUJ+/gx7wHKif28R81McgYWCwnrbfOtVBtCJmusLZcCT8Cdxu79gMmm+IXgzqqWObRzdYDeZrWQb4FRDNNnrMTwG3247j4QpQixdgB6j/6WCwUuNloEZvhKEwDQwu/eEYsK1qZfp+YP5Ozb9DmA1vV2vCiferV37aQeMq+GmJy/ZL4wp/8c+/E96TL84HjB0dBnHD18umHVyqTbvxj/z0xZbsd3ca3ZmV+eUcKE0rr/fMvArsZGeDnXMj2JFcZwBpiJDM5GwYUzvjjTAYpoBOpz0CdrQPwv1g0NJxvgM7YTTYmW+Hl0GnacysV7RfMjM7t2BZx+XmneSni6uLc+vdpuNahsHxNpgPOr6OYLtMoyNLzMt267znwpOgJm53v5iG2WzdK0zvgVmuwHR2tdHR1fEOmAO9QC07g/U5Agwi7meeBnyDRDTrXQbqZdm/BY+TWuro+o9lnAab4DpYAoNAixqYj2VXgPuog8fHtmjqoJ7vhKvhTrC9I3PLU5mugZVwDhwPBtEfgMHlFLgC3gu/ga1gewq1YlX7Wqf2Lf41lN7EX1Uw2PTp0zv7U7/+md/llSvC4sVLwy4u0/xTNIfAWiPT5dRrOlwOY2EAnAiPgdvyy7AjezbzTPo/uelkptFeYmY26ChvgWGwHnR0bTPoFO+DobAO7OCFpqPoXDfB1+CHoIPqsHb2fHNdvkVnMg+Diljnt4OOvg0MKAcy07vdek2B86AGCs1AMAEuhY/AFTASdNCZMAkMCAaTV8E8duamBoG/gwpQk0qI9WY203wH0+0wAjw2BirzVjPbbDDQZsECMH+Pl0QzyFjHq+AD8C44GWJ7ejJvvtbhZlgE1tH63AKeHBzZaFNgLRiErYd5PAPPgsd0LKhzh7TXb8BpQs6+vN8zcOCA7KmXyfwhLv+WuD2/A5sO5plJM5CcAO+AO8EOaJDR6uF8sMN6ltsIOm8ZDIOY7kXmvwv/AM/DLyDaD5i5BszrRvgW6NCF5nbRsd4J5nURDAUdrimL9YhpHmfmozAcHAlYh4lwoD6okxpMPg/WwaBRDoWH0WXT6Xhq6NR1i+AG+CXo7NeC7dSxTXcvXAXW85vwfTgVLCOa5TqScT/rbLv/D74Mp4DlGrQMSlvgQFbLBvH4mp9T6+n+WmyT6213vhmErK86md7g4/HeDtFcH9vu9kLtY7p2nx7oYLd7xZqvQDxG+6csLS0NZfyeTvw6vF//vqE/P6zV8Kdk2uGCaf8qNrbGzm3HfRm6w/EwCnQcO50NNo1msDkTPJsZOM6AMXAxRIdZyvx9MARWwVyItoyZR+BWMOCY5iwoNMu0jzjSMJ1ONgV01k9BtFeY0YHyzTN0vi1n4W74PUyDnvAR6AaxXczuMct1/UvwIpjegFWY3jouhifAej0Eq0Et58Md4KihEi6AiWBeLqvPbWAw1FHfB2qfbzrzq/AA3A6Pwng4HXbBeiiDwv1Ytces4xJ4Ch4ETwALIR4rtbOcvmA++UGnguVSMMCYzzowyJk2mvnE8q1PddzA1HwNdh3C8hvWISrU0kr4SH0Df1PKvyXlX3WIf92hsak3pwPv/GzmUwaffh2iy6qWVr2pdHaUO2EwjIYVEM+Gdio7nDYSesNsOAp0MB3GEdEtoLN5FlwMnvlczu+E5t0DdILlMBWGQ6Hp8GKHtx52ZucLHczg0h90Zh3DUcQ4sF52dus2AAaCzts1t3wqU/M7kMXyHyZBP7gS3LfQLHMjrAE1sj6WNxZ0UIOWbX4XWAfbbuByxLIMZoL1Pw1sWzTzUne16QzzwDodB8PAQGEwfAN4HCaAZetXm2EVaB6DlfCEC5j6jMjmGv6z/tbT4zQVPLZVYJvPhE0wH6zPM3AOnAyeRAx61m88eJIxkMZjrba2cQtsAOuxPDdl0vb2ug04VStWh+fvfgDF+IFPL5d4RfhAUzbwOL3h/R6fdBmkOqDZmQwSv4brwA78I7Az2sm1YtCR7LCPw3tB8zh+CK6B7qDz6QzmGfdldo+53yTQET3b22GnQ2PmGdJ8joX3g+Xbuf8C0XSm4+H7YL2mgPk6rwMOgwvgEngOTGs9dR6doDGL9XakY90q4ONQ2CbrZwAoBgOG7f4dWMdvwL2gUxoM3HcBaOfDh8A6jAad3GCYXx/LNhCZbhTMh7HQCwy+2jS4DM6GI+EF8PhY55+CFtvSsNRQj7jebR73l8G8/g2eBIPnEJgK/wnqrZa3wynwNvC4qf1kMKjfARvA9mpqYjs9dvYj+8X1kN9GFtvOStquqNYtyd8YvvvaXxBICDSMYLIpj7R9W7g+b+pbybUsFzP1XZot66qafELVurVscW6zSGkHWwZ2vvvgaXgAtMehPJtrcDzXe0aMptN5prUz6XA6imYn+xXoSPlm53WbZ/q18DWwDoVWywrPiNZlNVjOJjC9jhXtf5h5DE6EznAP6JwzwPboFAaagaDTm9btT8JWMO9nYQXoVNZ/NtwGnvU1A8OnwTJi0PBMfjN0Bfez7WIZBtPvwBFgP38Q1Md9dcg58GcoBfO2PrbTkUW02F4Dgc7aBWaC6c1fs9xvw/1g4LNsRzZzQXN0YdlOo6m9et8Etl97Ba6BR6EXdAf7g2meB8u3beZtuhOgAgwqt4HtUkOPj7YIbgD3sTwtatSw1A7/v24DTjXvyuzYkn8MW6Ke92/sDx3OdK6FYGexkxsQPDY6quayHUtHcd1DoCNHcx87uJ3TjlkLmh3tBlgK+WdZz6YGuJ5gJ7Rs9ys08zHgGED6gHkYDHQEz6TRKpmx7gYMnd+6OQIwmGkGDevn1O3WyyCj82jOWw+dzjZqBgTzMKhottt6GFiXgOa2P4BBznppamHbLOsBGARqZ/3MI3Ya23wXWB/zsQ5uzzfbaz4GS8uMad3X/DQ1Mlipn05eBu5jHexsBhQDlu2LZh0NOO5jWs10Bg21GQq2x7xd5+VZHJWYTyxvDPOa+6q9ZUazvndCCRhU3T+WxWz7mIIccntvGPMrHP3KQ15QOxRQTJ/izwj/c49Q/vPrwiwPfLKkQFLgAArEs8IBNqfVSYGkQFKg9RRIAaf1tEw5JQWSAs0okAJOMwK1cHObXJq2sC4pWVKgwyqQAk6HPTSpYkmBw0+BFHBa6ZhWhxpHOUUfDSeXfnXvE5NWyj1lkxQ4PBRIAaeVjiO/4NPlijBu4o6w5X8XhHEXvT9U+Kg2WVIgKZCngM/oD7nxSJz3LYp4D6OeAFfEOwgHnPK+RBHvHtS3aMo7xsW8Q1wbp+xHe4p40emvnvK+QhHvK9T73kKLjMp25mWNTbxaWFcaiur5TLQbO3aqDt181yJZUiApkKdAGwWc+md4B5hrDr9i8pPK1pryETjOzbVMNiWa+dUU7x6/9mmeRk3OUn4J7ZnTI/TYvitUr+GP0dxTH+oWHhtm1fy+yT3TxqRAUiApkBRICiQFkgJJgaRAUiApkBRICiQFkgJJgaRAUiApkBRICiQFkgJJgaRAUiApkBRICiQFkgJJgaRAUiApkBRICiQFkgJJgaRAUiApkBRICiQFkgJJgaRAUiApkBRICiQFkgJJgaRAUiApkBRICiQFkgJJgaRAUiApkBRICiQFkgJJgaRAUiApkBRICiQFkgJJgaRAUiApkBRICiQFkgJJgaRAUiApkBRICiQFkgJJgaRAUiApkBRICiQFkgJJgaRAUiApkBRICiQFkgJJgSYV+P+uoAPHqJz2mwAAAABJRU5ErkJggg==" alt="Texas A&M University MS Analytics, Mays Business School" width="250"/>
# MAGIC
# MAGIC # ISTM 637 — Prediction Model Notebook
# MAGIC **MS Analytics · Texas A&M University · Mays Business School**
# MAGIC
# MAGIC This notebook trains a model that predicts a well's **daily oil rate** from its age and
# MAGIC attributes, registers it in **Unity Catalog** with MLflow, and saves a **`well_forecast`
# MAGIC table** that your **Databricks App** reads to display each well's forward production curve.
# MAGIC
# MAGIC > Prerequisite: you have already run the setup/starter notebook so the star schema
# MAGIC > (`fact_production`, `dim_well`, `dim_date`) exists in your catalog/schema.
# MAGIC > Runs on Free Edition serverless (CPU) — no GPU or model-serving endpoint required.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1 — Parameters

# COMMAND ----------

NETID   = 831004060
CATALOG = f"istm637_{NETID}"
SCHEMA  = "oilgas"
MODEL_NAME = f"{CATALOG}.{SCHEMA}.oil_rate_predictor"   # 3-level UC name
spark.sql(f"USE CATALOG {CATALOG}"); spark.sql(f"USE SCHEMA {SCHEMA}")
print("Model will be registered as:", MODEL_NAME)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2 — Build the feature table from the star schema
# MAGIC
# MAGIC We join the fact to both dimensions and engineer `days_online`
# MAGIC (`calendar_date − completion_date`). We keep producing wells and rows from completion
# MAGIC onward. The target is the daily `oil_bbl`.

# COMMAND ----------

feat_df = spark.sql(f"""
  SELECT
    f.oil_bbl                                            AS target_oil_bbl,
    DATEDIFF(d.calendar_date, w.completion_date)         AS days_online,
    w.lateral_length_ft,
    w.initial_oil_potential_bopd,
    f.choke_size_64ths,
    f.tubing_pressure_psi,
    f.casing_pressure_psi,
    w.basin,
    w.target_formation,
    w.well_type
  FROM {CATALOG}.{SCHEMA}.fact_production f
  JOIN {CATALOG}.{SCHEMA}.dim_well w ON f.well_id = w.well_id
  JOIN {CATALOG}.{SCHEMA}.dim_date d ON f.date_id = d.date_id
  WHERE w.status = 'Producing'
    AND DATEDIFF(d.calendar_date, w.completion_date) >= 0
""")

pdf = feat_df.toPandas()          # ~17k rows — fits comfortably in memory
print("rows:", len(pdf))
display(feat_df.limit(5))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3 — Train / test split and model pipeline

# COMMAND ----------

from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split

NUM = ["days_online", "lateral_length_ft", "initial_oil_potential_bopd",
       "choke_size_64ths", "tubing_pressure_psi", "casing_pressure_psi"]
CAT = ["basin", "target_formation", "well_type"]

X = pdf[NUM + CAT]
y = pdf["target_oil_bbl"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

pre = ColumnTransformer(
    [("cat", OneHotEncoder(handle_unknown="ignore"), CAT)],
    remainder="passthrough")
model = Pipeline([("prep", pre),
                  ("reg", HistGradientBoostingRegressor(max_iter=200, random_state=42))])
model.fit(X_train, y_train)
print("trained on", len(X_train), "rows")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4 — Evaluate

# COMMAND ----------

import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

pred = model.predict(X_test)
mae  = mean_absolute_error(y_test, pred)
rmse = mean_squared_error(y_test, pred) ** 0.5
r2   = r2_score(y_test, pred)
print(f"MAE  = {mae:,.1f} bbl/day")
print(f"RMSE = {rmse:,.1f} bbl/day")
print(f"R2   = {r2:.3f}")
# TODO (extend): try adding interaction features or a different regressor and beat this R2.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5 — Log & register the model in Unity Catalog (MLflow)
# MAGIC
# MAGIC Setting the registry to `databricks-uc` registers the model as a **governed Unity Catalog
# MAGIC object** — discoverable and shareable like your tables. We log a signature so the app knows
# MAGIC the expected input schema, then promote the version with the `@champion` alias.
# MAGIC
# MAGIC > **MLflow 2 vs 3:** your notebook's *serverless environment version* determines the MLflow
# MAGIC > version — **version 5 ships MLflow 3.x; version 4 and earlier ship MLflow 2.x** (check the
# MAGIC > Environment side panel). MLflow 3 renamed `log_model(artifact_path=…)` to
# MAGIC > `log_model(name=…)`, so the cell below detects your version and uses the right parameter —
# MAGIC > it runs correctly on either environment.
# MAGIC
# MAGIC > **Free Edition storage:** Free Edition uses Databricks default storage, which **denies
# MAGIC > MLflow's default direct-to-S3 artifact upload** for model versions (an
# MAGIC > `AccessDenied … explicit deny in a resource-based policy` error). The cell below sets
# MAGIC > `MLFLOW_USE_DATABRICKS_SDK_MODEL_ARTIFACTS_REPO_FOR_UC=True` — Databricks' documented
# MAGIC > fix, which uploads through the SDK instead — and includes a Volume-save safety net just
# MAGIC > in case.

# COMMAND ----------

import os
# Free Edition workspaces use Databricks default storage, whose bucket policy DENIES
# MLflow's default direct-to-S3 upload of model artifacts ("AccessDenied ... explicit
# deny in a resource-based policy"). This documented switch routes the upload through
# the Databricks SDK/API instead, which is permitted:
os.environ["MLFLOW_USE_DATABRICKS_SDK_MODEL_ARTIFACTS_REPO_FOR_UC"] = "True"

import mlflow
from mlflow import MlflowClient
from mlflow.models import infer_signature

# Unity Catalog is the target registry (the default in MLflow 3; explicit for MLflow 2).
mlflow.set_registry_uri("databricks-uc")
signature = infer_signature(X_test, pred)

# MLflow 3 renamed log_model's `artifact_path=` parameter to `name=`.
# Serverless ENVIRONMENT VERSION matters here: version 5 ships MLflow 3.x,
# version 4 and earlier ship MLflow 2.x. This cell works on BOTH:
MLFLOW_3 = int(mlflow.__version__.split(".")[0]) >= 3
print("MLflow version:", mlflow.__version__, "->", "using name=" if MLFLOW_3 else "using artifact_path=")
log_kwargs = {("name" if MLFLOW_3 else "artifact_path"): "model"}

try:
    with mlflow.start_run(run_name="oil_rate_predictor") as run:
        mlflow.log_params({"max_iter": 200, "model": "HistGradientBoostingRegressor"})
        mlflow.log_metrics({"mae": mae, "rmse": rmse, "r2": r2})
        info = mlflow.sklearn.log_model(
            sk_model=model,
            signature=signature,
            input_example=X_test.head(3),
            registered_model_name=MODEL_NAME,
            **log_kwargs,
        )
    print("Registered:", MODEL_NAME, "version", info.registered_model_version)
    # Promote this version to @champion (the alias the app-side stretch goal loads)
    MlflowClient().set_registered_model_alias(MODEL_NAME, "champion", info.registered_model_version)
    print("Alias @champion ->", MODEL_NAME)
except Exception as e:
    if "AccessDenied" not in str(e) and "S3UploadFailedError" not in str(e):
        raise
    # Safety net: if this workspace still blocks model-artifact uploads, save the
    # trained pipeline to your UC Volume instead and continue with the project.
    import joblib
    fallback_path = f"/Volumes/{CATALOG}/{SCHEMA}/raw/oil_rate_predictor.joblib"
    joblib.dump(model, fallback_path)
    print("UC model registration is blocked on this workspace.")
    print(f"Saved the trained model to your Volume instead: {fallback_path}")
    print("Screenshot this file in Catalog Explorer for the Part 6 deliverable —")
    print("the well_forecast step below is unaffected and still works.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6 — Forecast helper
# MAGIC
# MAGIC Given a `well_id` and a horizon, we advance `days_online` forward while holding the well's
# MAGIC attributes and most recent operating conditions constant, then predict the daily rate.

# COMMAND ----------

import pandas as pd

def _latest_features(well_id):
    return spark.sql(f"""
      WITH last AS (
        SELECT DATEDIFF(d.calendar_date, w.completion_date) AS days_online,
               w.lateral_length_ft, w.initial_oil_potential_bopd,
               f.choke_size_64ths, f.tubing_pressure_psi, f.casing_pressure_psi,
               w.basin, w.target_formation, w.well_type,
               ROW_NUMBER() OVER (ORDER BY d.calendar_date DESC) AS rn
        FROM {CATALOG}.{SCHEMA}.fact_production f
        JOIN {CATALOG}.{SCHEMA}.dim_well w ON f.well_id = w.well_id
        JOIN {CATALOG}.{SCHEMA}.dim_date d ON f.date_id = d.date_id
        WHERE f.well_id = '{well_id}')
      SELECT days_online, lateral_length_ft, initial_oil_potential_bopd,
             choke_size_64ths, tubing_pressure_psi, casing_pressure_psi,
             basin, target_formation, well_type
      FROM last WHERE rn = 1
    """).toPandas().iloc[0]

def forecast_well(model, well_id, horizon_days=180):
    base = _latest_features(well_id)
    rows = []
    for i in range(1, horizon_days + 1):
        r = base.copy()
        r["days_online"] = int(base["days_online"]) + i
        rows.append(r)
    fut = pd.DataFrame(rows)[NUM + CAT]
    fut_pred = model.predict(fut).clip(min=0)
    return pd.DataFrame({"day_ahead": range(1, horizon_days + 1), "predicted_oil_bbl": fut_pred})

# Demo
example_well = spark.sql(f"SELECT well_id FROM {CATALOG}.{SCHEMA}.dim_well WHERE status='Producing' LIMIT 1").collect()[0][0]
fc = forecast_well(model, example_well, 180)
print(f"180-day forecast for {example_well}: total = {fc.predicted_oil_bbl.sum():,.0f} bbl")
display(spark.createDataFrame(fc))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7 — Save the `well_forecast` table (this is what the App reads)
# MAGIC
# MAGIC Pre-computing forecasts keeps your Part 7 app **light on compute**: the app just runs a
# MAGIC simple SELECT instead of loading the model. We forecast every producing well once and
# MAGIC save the results as a Unity Catalog table.

# COMMAND ----------

producing = [r[0] for r in spark.sql(
    f"SELECT well_id FROM {CATALOG}.{SCHEMA}.dim_well WHERE status='Producing'").collect()]

frames = []
for w in producing:
    f = forecast_well(model, w, 180)
    f.insert(0, "well_id", w)
    frames.append(f)

all_fc = pd.concat(frames, ignore_index=True)
(spark.createDataFrame(all_fc)
      .write.mode("overwrite")
      .saveAsTable(f"{CATALOG}.{SCHEMA}.well_forecast"))
n = spark.table(f"{CATALOG}.{SCHEMA}.well_forecast").count()
print(f"well_forecast saved: {n:,} rows ({len(producing)} wells × 180 days)")

# The app's query is then simply:
#   SELECT day_ahead, predicted_oil_bbl
#   FROM {CATALOG}.{SCHEMA}.well_forecast WHERE well_id = :well
#
# Optional stretch (not required): load the registered model live in the app instead —
#   app_model = mlflow.pyfunc.load_model(f"models:/{MODEL_NAME}@champion")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC ### How this plugs into the project
# MAGIC - **Part 6 (this notebook):** train, evaluate, and register the model in Unity Catalog,
# MAGIC   then save the `well_forecast` table.
# MAGIC - **Part 7 (the app):** the Databricks App queries your tables for a well's production
# MAGIC   history and reads `well_forecast` for its forward curve — history + prediction from the
# MAGIC   same governed data, with minimal compute.
# MAGIC
# MAGIC Commit this notebook to your GitHub repo alongside the starter notebook.
# MAGIC